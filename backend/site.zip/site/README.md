Phocal
---
#### Team Total Hackjob  
Abbey Ciolek, Josh Billingham, Otto Sipe, Josh Stern, Patrick Wilson  

22 April 2014  
EECS 493

Website: http://phocal.com.s3-website-us-east-1.amazonaws.com/

You can also view this site by opening `index.html` in a browser.
